package com.example.oms.studentproject.Projection;

public interface Projection {


     String getname();
    String getemail();
    String getpassword();
    String getlocation();





}
